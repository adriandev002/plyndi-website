// Admin page behaviour: image upload (resized in the browser first), tasting rows, slug and delete helpers.

/** Scales a photo down so its longest side is at most maxSize, as WebP (or JPEG where WebP can't be encoded) */
async function resize(file, maxSize) {
  const bitmap = await createImageBitmap(file)
  const scale = Math.min(1, maxSize / Math.max(bitmap.width, bitmap.height))
  const canvas = document.createElement('canvas')
  canvas.width = Math.round(bitmap.width * scale)
  canvas.height = Math.round(bitmap.height * scale)
  canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height)
  bitmap.close()
  const encode = (type) => new Promise((resolve) => canvas.toBlob(resolve, type, 0.85))
  const webp = await encode('image/webp')
  return webp && webp.type === 'image/webp' ? webp : encode('image/jpeg')
}

function setupImageField(field) {
  const input = field.querySelector('input[type=hidden]')
  const preview = field.querySelector('.preview')
  const picker = field.querySelector('input[type=file]')
  const remove = field.querySelector('[data-remove-image]')
  const status = field.querySelector('.status')
  const maxSize = Number(field.dataset.maxSize) || 1600

  const show = (key, url) => {
    input.value = key
    preview.src = url || ''
    preview.hidden = !key
    remove.hidden = !key
  }

  picker.addEventListener('change', async () => {
    const file = picker.files && picker.files[0]
    picker.value = ''
    if (!file) return
    status.textContent = 'Uploading…'
    try {
      const blob = await resize(file, maxSize)
      const res = await fetch('/api/admin/media', { method: 'POST', headers: { 'content-type': blob.type }, body: blob })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error(data.error || `Upload failed (${res.status})`)
      show(data.key, `/media/${data.key}`)
      status.textContent = ''
    } catch (err) {
      status.textContent = err.message || 'Upload failed'
    }
  })

  remove.addEventListener('click', () => show('', ''))
}

function setupRow(row) {
  row.querySelectorAll('.image-field').forEach(setupImageField)
  const remove = row.querySelector('[data-remove-row]')
  if (remove) remove.addEventListener('click', () => row.remove())
}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.image-field').forEach((field) => {
    if (!field.closest('.tasting-row')) setupImageField(field)
  })
  document.querySelectorAll('.tasting-row').forEach(setupRow)

  const addTasting = document.querySelector('[data-add-tasting]')
  const template = document.getElementById('tasting-template')
  const list = document.querySelector('[data-tastings]')
  if (addTasting && template && list) {
    addTasting.addEventListener('click', () => {
      const row = template.content.firstElementChild.cloneNode(true)
      list.appendChild(row)
      setupRow(row)
      row.querySelector('input[name=tastingName]').focus()
    })
  }

  // New tours: suggest a slug from the English title until the slug is edited by hand
  const form = document.querySelector('.tour-form[data-new]')
  if (form) {
    const title = form.querySelector('input[name=title]')
    const slug = form.querySelector('input[name=slug]')
    let edited = slug.value !== ''
    slug.addEventListener('input', () => { edited = slug.value !== '' })
    title.addEventListener('input', () => {
      if (edited) return
      slug.value = title.value.normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase()
        .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 96)
    })
  }

  document.querySelectorAll('form[data-confirm]').forEach((f) => {
    f.addEventListener('submit', (e) => {
      if (!window.confirm(f.dataset.confirm)) e.preventDefault()
    })
  })
})
