-- Tours. Text fields that visitors read have an optional Chinese (_zh) twin;
-- the website falls back to English when the Chinese one is empty.
CREATE TABLE tours (
  id               TEXT PRIMARY KEY,
  slug             TEXT NOT NULL UNIQUE,
  category         TEXT NOT NULL CHECK (category IN ('free', 'food', 'night', 'hiking', 'special')),
  title            TEXT NOT NULL,
  title_zh         TEXT,
  location         TEXT,
  location_zh      TEXT,
  price            REAL CHECK (price IS NULL OR price >= 0), -- 0 = free, NULL = price on request
  duration         TEXT,
  duration_zh      TEXT,
  meeting_point    TEXT,
  meeting_point_zh TEXT,
  start_time       TEXT,
  start_time_zh    TEXT,
  main_image       TEXT, -- key in the MEDIA bucket
  featured         INTEGER NOT NULL DEFAULT 0,
  coming_soon      INTEGER NOT NULL DEFAULT 0,
  description      TEXT,
  description_zh   TEXT,
  body             TEXT, -- blank line between paragraphs
  body_zh          TEXT,
  highlights       TEXT NOT NULL DEFAULT '[]', -- JSON string[]
  highlights_zh    TEXT NOT NULL DEFAULT '[]',
  tastings         TEXT NOT NULL DEFAULT '[]', -- JSON [{ name, nameZh, image }]
  note             TEXT,
  note_zh          TEXT,
  published        INTEGER NOT NULL DEFAULT 1,
  sort_order       INTEGER NOT NULL DEFAULT 0,
  created_at       TEXT NOT NULL,
  updated_at       TEXT NOT NULL
);

CREATE INDEX tours_listing ON tours (published, sort_order, created_at);

-- Failed admin logins per IP, to slow down password guessing
CREATE TABLE login_attempts (
  ip         TEXT PRIMARY KEY,
  failures   INTEGER NOT NULL,
  first_at   INTEGER NOT NULL -- epoch ms of the first failure in the current window
);
