// Small client for the CMS admin API, shared by the import scripts.

export function requireEnv(name) {
  const value = process.env[name]
  if (!value) {
    console.error(`Set ${name} first, e.g. ${name}=... npm run <script>`)
    process.exit(1)
  }
  return value
}

/** Signs in and returns helpers bound to that session */
export async function connect(baseUrl, password) {
  const base = baseUrl.replace(/\/+$/, '')
  const login = await fetch(`${base}/api/admin/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ password }),
  })
  if (!login.ok) throw new Error(`Sign-in failed (${login.status}): ${await login.text()}`)
  const cookie = login.headers.get('set-cookie').split(';')[0]

  async function request(method, path, body, contentType = 'application/json') {
    const res = await fetch(`${base}${path}`, {
      method,
      headers: { cookie, ...(body ? { 'content-type': contentType } : {}) },
      body: body && contentType === 'application/json' ? JSON.stringify(body) : body,
    })
    const data = await res.json().catch(() => ({}))
    if (!res.ok) throw new Error(`${method} ${path} failed (${res.status}): ${JSON.stringify(data)}`)
    return data
  }

  return {
    /** Slugs of every tour already in the CMS, drafts included */
    async existingSlugs() {
      const { tours } = await request('GET', '/api/admin/tours')
      return new Set(tours.map((t) => t.slug))
    },
    /** Creates or replaces the tour with this slug */
    putTour(slug, tour) {
      return request('PUT', `/api/admin/tours/${encodeURIComponent(slug)}`, tour)
    },
    /** Downloads an image and stores it in the CMS; returns its media key */
    async copyImage(url) {
      const res = await fetch(url)
      if (!res.ok) throw new Error(`Downloading ${url} failed (${res.status})`)
      const type = (res.headers.get('content-type') || '').split(';')[0]
      const { key } = await request('POST', '/api/admin/media', new Uint8Array(await res.arrayBuffer()), type)
      return key
    },
  }
}

/** Saves each tour, skipping slugs the CMS already has unless `overwrite` */
export async function importTours(cms, tours, { overwrite = false, dryRun = false } = {}) {
  const existing = await cms.existingSlugs()
  const counts = { created: 0, updated: 0, skipped: 0 }
  for (const { slug, label, build } of tours) {
    if (existing.has(slug) && !overwrite) {
      console.log(`- skip  ${slug} (already in the CMS; use --overwrite to replace it)`)
      counts.skipped++
      continue
    }
    if (dryRun) {
      console.log(`- would ${existing.has(slug) ? 'update' : 'create'} ${slug}: ${label}`)
      continue
    }
    const { created } = await cms.putTour(slug, await build())
    console.log(`- ${created ? 'created' : 'updated'} ${slug}: ${label}`)
    counts[created ? 'created' : 'updated']++
  }
  console.log(`\nDone: ${counts.created} created, ${counts.updated} updated, ${counts.skipped} skipped${dryRun ? ' (dry run, nothing written)' : ''}.`)
}
