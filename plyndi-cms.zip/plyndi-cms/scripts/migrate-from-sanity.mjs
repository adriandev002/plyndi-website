// Copies the published tours (and their photos) from Sanity into the CMS.
//
//   CMS_URL=https://plyndi-cms.<you>.workers.dev CMS_PASSWORD=... npm run migrate:sanity -- [--dry-run] [--overwrite]
//
// Optional: SANITY_PROJECT_ID (default ifzr2wb3), SANITY_DATASET (default production),
// SANITY_TOKEN (only needed if the dataset is private).

import { connect, importTours, requireEnv } from './cms-client.mjs'

const CATEGORIES = ['free', 'food', 'night', 'hiking', 'special']
const args = new Set(process.argv.slice(2))

const projectId = process.env.SANITY_PROJECT_ID || 'ifzr2wb3'
const dataset = process.env.SANITY_DATASET || 'production'
const queryUrl = process.env.SANITY_QUERY_URL || `https://${projectId}.api.sanity.io/v2024-01-01/data/query/${dataset}`

const QUERY = `*[_type == "tourPackage" && !(_id in path("drafts.**"))] | order(_createdAt asc){
  _id, _createdAt, title, "slug": slug.current, category, location, price, duration, meetingPoint, startTime,
  "mainImage": mainImage.asset->url, featured, comingSoon, description, body, highlights,
  tastings[]{ name, nameZh, "image": image.asset->url }, note
}`

const slugify = (text) =>
  String(text || '')
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 96)

/** Sanity's `body` is plain text, but older documents may hold Portable Text blocks */
function bodyText(body) {
  if (typeof body === 'string') return body
  if (!Array.isArray(body)) return null
  return body
    .filter((block) => block && block._type === 'block')
    .map((block) => (block.children || []).map((child) => child.text || '').join(''))
    .filter(Boolean)
    .join('\n\n')
}

/** Sanity's image CDN resizes on the fly; take a web-sized WebP rather than the original upload */
const sized = (url, width) => `${url}?w=${width}&fit=max&fm=webp&q=85`

async function fetchSanityTours() {
  const url = `${queryUrl}?query=${encodeURIComponent(QUERY)}&perspective=published`
  const headers = process.env.SANITY_TOKEN ? { authorization: `Bearer ${process.env.SANITY_TOKEN}` } : {}
  const res = await fetch(url, { headers })
  if (!res.ok) throw new Error(`Sanity query failed (${res.status}): ${await res.text()}`)
  return (await res.json()).result || []
}

const cms = await connect(requireEnv('CMS_URL'), requireEnv('CMS_PASSWORD'))
const docs = await fetchSanityTours()
console.log(`Found ${docs.length} published tour(s) in Sanity project ${projectId}/${dataset}.\n`)

const tours = []
for (const doc of docs) {
  const slug = doc.slug || slugify(doc.title) || doc._id
  if (!CATEGORIES.includes(doc.category)) {
    console.log(`- skip  ${slug}: category "${doc.category}" is not one the website shows`)
    continue
  }
  tours.push({
    slug,
    label: doc.title,
    build: async () => ({
      title: doc.title || 'Untitled Tour',
      category: doc.category,
      location: doc.location ?? null,
      price: typeof doc.price === 'number' ? doc.price : null,
      duration: doc.duration ?? null,
      meetingPoint: doc.meetingPoint ?? null,
      startTime: doc.startTime ?? null,
      mainImage: doc.mainImage ? await cms.copyImage(sized(doc.mainImage, 1600)) : null,
      featured: Boolean(doc.featured),
      comingSoon: Boolean(doc.comingSoon),
      description: doc.description ?? null,
      body: bodyText(doc.body),
      highlights: Array.isArray(doc.highlights) ? doc.highlights.filter((h) => typeof h === 'string') : [],
      tastings: await Promise.all(
        (doc.tastings || []).map(async (t) => ({
          name: t.name || '',
          nameZh: t.nameZh || null,
          image: t.image ? await cms.copyImage(sized(t.image, 800)) : null,
        })),
      ),
      note: doc.note ?? null,
      published: true,
      createdAt: doc._createdAt,
    }),
  })
}

await importTours(cms, tours, { overwrite: args.has('--overwrite'), dryRun: args.has('--dry-run') })
