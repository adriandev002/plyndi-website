// Adds the website's built-in launch tours (lib/tours.ts in wanderasia-web) to the CMS as published and
// featured, so the home page keeps showing them. Tours whose slug already exists are left alone.
//
//   CMS_URL=https://plyndi-cms.<you>.workers.dev CMS_PASSWORD=... npm run seed:launch-tours -- [--dry-run] [--overwrite]

import { readFile } from 'node:fs/promises'
import { connect, importTours, requireEnv } from './cms-client.mjs'

const args = new Set(process.argv.slice(2))
const cms = await connect(requireEnv('CMS_URL'), requireEnv('CMS_PASSWORD'))
const launchTours = JSON.parse(await readFile(new URL('./launch-tours.json', import.meta.url), 'utf8'))

await importTours(
  cms,
  launchTours.map(({ slug, ...tour }) => ({ slug, label: tour.title, build: async () => ({ ...tour, published: true, featured: true }) })),
  { overwrite: args.has('--overwrite'), dryRun: args.has('--dry-run') },
)
