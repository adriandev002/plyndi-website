# plyndi-cms

Content manager for the [Wander Asia website](https://github.com/wanderasiatw/wanderasia-web). It replaces Sanity for tours.

- **Admin** at `/admin`: sign in, then add, edit, unpublish or delete tours. Each text field has an English box and a 中文 box side by side. Photos are resized in the browser before upload.
- **Public API** at `/api/v1`: read-only JSON the website fetches. Only published tours are included.
- Runs on **Cloudflare Workers** with **D1** (SQLite database) and **R2** (image storage). All three are within Cloudflare's free tier at Wander Asia's size.

## Costs

| Service | Free allowance | What we use | Monthly cost |
| --- | --- | --- | --- |
| Workers (Free plan) | 100,000 requests/day | API calls from the website (at most about one per page every 60 s), admin use, image views | $0 |
| D1 | 5 GB storage, 5 million rows read/day, 100,000 rows written/day | A few dozen tour rows | $0 |
| R2 | 10 GB storage, 1M writes and 10M reads per month, no download fees | Tour photos, about 50–300 KB each after resizing | $0 |
| `*.workers.dev` address | Included | `https://plyndi-cms.<account>.workers.dev` | $0 |
| **Total** | | | **$0/month** |

Notes:
- R2 asks for a card or PayPal before you can turn it on, even on the free tier. You are charged nothing within the allowance.
- If traffic outgrows the free tier, Workers Paid costs $5/month and covers 10 million requests.
- A custom domain such as `cms.wanderasia.tw` is optional. It is free if the domain's DNS is on Cloudflare.
- Check Cloudflare's pricing pages for current numbers. Since September 2026, D1 queries on the Free plan fail once a daily limit is used up, until midnight UTC; this site uses a tiny fraction of the limit.

## Chinese content

The site is bilingual (EN / 中文), with the language switched in the browser. The CMS handles that like this:

- **One tour, both languages.** Every text visitors read has an optional Chinese twin: `title`/`titleZh`, `location`/`locationZh`, `startTime`/`startTimeZh`, `duration`/`durationZh`, `meetingPoint`/`meetingPointZh`, `description`/`descriptionZh`, `body`/`bodyZh`, `highlights`/`highlightsZh`, `note`/`noteZh`. Tastings keep their existing `name`/`nameZh`.
- **Facts are shared.** Price, category, photos, flags and order are entered once, so the two languages can't disagree.
- **English is required, Chinese is optional.** The website shows the English text wherever the Chinese is empty, so a tour can go live before it is translated. The admin list flags tours with no Chinese title.
- **Traditional Chinese** (`zh-Hant`, Taiwan) is assumed in the admin and the API.
- The API returns both languages in one response, because the site switches language without reloading.

The website does not show the `…Zh` fields yet. That needs changes to the tour card, tour pop-up and tour page, so it is a separate step.

## Run it locally

```bash
npm install
cp .dev.vars.example .dev.vars   # then set a password (12+ characters) and a session secret
npm run db:migrate:local
npm run dev                      # http://localhost:8787/admin
npm test                         # API, admin and validation tests, in the Workers runtime
```

## Deploy (one time)

Needs a free Cloudflare account.

```bash
npx wrangler login
npx wrangler d1 create plyndi-cms         # copy the database_id it prints into wrangler.jsonc
npx wrangler r2 bucket create plyndi-cms-media
npm run db:migrate:remote
npx wrangler secret put ADMIN_PASSWORD    # a long password, 12+ characters
npx wrangler secret put SESSION_SECRET    # e.g. the output of: openssl rand -hex 32
npm run deploy                            # prints https://plyndi-cms.<account>.workers.dev
```

Optional: set `SITE_URL` in `wrangler.jsonc` to the website's address, for "View on site" links in the admin, and deploy again.

## Move from Sanity to the CMS

1. **Copy the tours from Sanity.** This copies every published `tourPackage`, re-uploading its photos. Tours that already exist in the CMS are skipped unless you add `--overwrite`.

   ```bash
   CMS_URL=https://plyndi-cms.<account>.workers.dev CMS_PASSWORD=... npm run migrate:sanity -- --dry-run
   CMS_URL=https://plyndi-cms.<account>.workers.dev CMS_PASSWORD=... npm run migrate:sanity
   ```

2. **Only if step 1 found no tours** (the website is currently showing its built-in launch tours), add those launch tours so editors can work on them:

   ```bash
   CMS_URL=... CMS_PASSWORD=... npm run seed:launch-tours
   ```

3. Check the tours at `/admin` and at `https://plyndi-cms.<account>.workers.dev/api/v1/tours`.
4. On the website's host, set `CMS_API_URL=https://plyndi-cms.<account>.workers.dev` and redeploy. Pages now read the CMS. Unset it to go back to Sanity.
5. Once the live site looks right, remove Sanity from the website: delete `lib/sanity.ts` and `sanity/`, drop the Sanity branches in `lib/cms.ts`, and uninstall `@sanity/client`, `@sanity/image-url` and `@portabletext/react`.

## API

All responses are JSON. Image fields are full URLs, or `null`.

### `GET /api/v1/tours`

Published tours, ordered by position (lowest first), then newest first. Add `?featured=1` for featured tours only.

```json
{ "tours": [ { "id": "…", "slug": "dongmen-street-food-tour", "category": "food", "title": "Dongmen Street Food Tour", "titleZh": "東門美食導覽", "price": null, "…": "…" } ] }
```

### `GET /api/v1/tours/:slug`

One published tour as `{ "tour": { … } }`, or 404.

### Tour fields

| Field | Type | Notes |
| --- | --- | --- |
| `id`, `slug` | string | `slug` is the web address: `/tours/<slug>` |
| `category` | string | `free`, `food`, `night`, `hiking` or `special` |
| `title`, `titleZh` | string, string or null | English title is required |
| `location`, `locationZh` | string or null | |
| `price` | number or null | USD. `0` = free, `null` = price on request |
| `duration`, `durationZh` | string or null | |
| `meetingPoint`, `meetingPointZh` | string or null | |
| `startTime`, `startTimeZh` | string or null | |
| `mainImage` | URL or null | |
| `featured` | boolean | Shown on the home page |
| `comingSoon` | boolean | Listed, but details not published yet |
| `description`, `descriptionZh` | string or null | Short text for cards |
| `body`, `bodyZh` | string or null | Blank line between paragraphs |
| `highlights`, `highlightsZh` | string[] | |
| `tastings` | `{ name, nameZh, image }[]` | `image` is a URL or null |
| `note`, `noteZh` | string or null | |
| `sortOrder` | number | Lower comes first |
| `createdAt`, `updatedAt` | ISO date | |

### Admin API (used by the scripts)

Sign in with `POST /api/admin/login` and `{ "password": "…" }`, then send the returned cookie:

- `GET /api/admin/tours`: every tour, drafts included, with image keys instead of URLs.
- `PUT /api/admin/tours/:slug`: create or replace the tour with that slug. An optional `createdAt` is kept when creating.
- `POST /api/admin/media`: the raw JPEG, PNG or WebP bytes (max 5 MB) with a matching `Content-Type`. Returns `{ key, url }`.

## Security

- One shared admin password, stored as a Cloudflare secret. Sessions last 7 days in a signed, HTTP-only cookie. Changing the password signs everyone out.
- After 10 wrong passwords from one IP, sign-in is blocked for 15 minutes.
- Admin forms only accept submissions from the CMS's own pages, and admin pages send strict security headers.
- Uploads must really be JPEG, PNG or WebP; SVG and other files are refused.
- For a login per person, put Cloudflare Access (free for up to 50 users) in front of `/admin*` and `/api/admin*`.

## Known limits

- Replacing or removing a photo leaves the old file in R2. At this size the storage cost is nil.
- Categories are fixed in code (`src/tours.ts`), matching the website's rows.
