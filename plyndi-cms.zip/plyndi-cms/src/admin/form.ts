import { TEXT_LIMITS } from '../tours'

/** Turns the tour form into the object validateTour() expects */
export function formToTour(form: FormData): Record<string, unknown> {
  const text = (key: string) => {
    const v = form.get(key)
    return typeof v === 'string' ? v : ''
  }
  const all = (key: string) => form.getAll(key).map((v) => (typeof v === 'string' ? v : ''))
  const number = (key: string) => (text(key).trim() === '' ? null : Number(text(key)))

  const tour: Record<string, unknown> = {}
  for (const key of Object.keys(TEXT_LIMITS)) {
    tour[key] = text(key)
    tour[`${key}Zh`] = text(`${key}Zh`)
  }

  const zh = all('tastingNameZh')
  const images = all('tastingImage')
  return {
    ...tour,
    slug: text('slug'),
    category: text('category'),
    price: number('price'),
    sortOrder: number('sortOrder'),
    mainImage: text('mainImage'),
    featured: form.has('featured'),
    comingSoon: form.has('comingSoon'),
    published: form.has('published'),
    highlights: text('highlights').split('\n'),
    highlightsZh: text('highlightsZh').split('\n'),
    tastings: all('tastingName').map((name, i) => ({ name, nameZh: zh[i] ?? '', image: images[i] ?? '' })),
  }
}
