import type { Child, FC } from 'hono/jsx'
import { CATEGORIES, type FieldErrors, type Tasting, type Tour } from '../tours'

/** Field values a form shows: a saved tour, the defaults for a new one, or what was just submitted */
export type TourValues = Record<string, unknown>

export const NEW_TOUR: TourValues = { category: 'food', published: true, sortOrder: 0 }

const str = (v: unknown) => (typeof v === 'string' ? v : '')
const lines = (v: unknown) => (Array.isArray(v) ? v.join('\n') : '')
const numberText = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? String(v) : '')

export function priceLabel(price: number | null) {
  if (price === 0) return 'Free'
  if (price == null) return 'On request'
  return `$${price.toLocaleString('en-US')} USD`
}

export const Layout: FC<{ title: string; signedIn?: boolean; children?: Child }> = ({ title, signedIn, children }) => (
  <html lang="en">
    <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta name="robots" content="noindex" />
      <link rel="icon" href="data:," />
      <title>{`${title} · Plyndi CMS`}</title>
      <link rel="stylesheet" href="/static/admin.css" />
      <script src="/static/admin.js" defer />
    </head>
    <body>
      <header class="topbar">
        <a href="/admin/tours" class="brand">Plyndi CMS</a>
        {signedIn && (
          <nav>
            <a href="/admin/tours">Tours</a>
            <form method="post" action="/admin/logout">
              <button type="submit" class="link">Sign out</button>
            </form>
          </nav>
        )}
      </header>
      <main class="wrap">{children}</main>
    </body>
  </html>
)

export const LoginPage: FC<{ error?: string }> = ({ error }) => (
  <Layout title="Sign in">
    <form method="post" action="/admin/login" class="card login">
      <h1>Sign in</h1>
      {error && <p class="alert alert-error">{error}</p>}
      <label class="field">
        <span>Password</span>
        <input type="password" name="password" autocomplete="current-password" required autofocus />
      </label>
      <button type="submit" class="btn btn-primary">Sign in</button>
    </form>
  </Layout>
)

export const ToursPage: FC<{ tours: Tour[]; siteUrl?: string; notice?: string }> = ({ tours, siteUrl, notice }) => (
  <Layout title="Tours" signedIn>
    <div class="page-head">
      <h1>Tours</h1>
      <a href="/admin/tours/new" class="btn btn-primary">New tour</a>
    </div>
    {notice && <p class="alert alert-ok">{notice}</p>}
    {tours.length === 0 && (
      <p class="empty">No tours yet. Until you publish one, the website shows its built-in launch tours.</p>
    )}
    {CATEGORIES.map((cat) => {
      const rows = tours.filter((t) => t.category === cat.key)
      if (rows.length === 0) return null
      return (
        <section class="group">
          <h2>{cat.label}</h2>
          <table class="list">
            <thead>
              <tr>
                <th>Tour</th>
                <th>Price</th>
                <th>Status</th>
                <th>Updated</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {rows.map((t) => (
                <tr>
                  <td>
                    <a href={`/admin/tours/${t.id}`} class="title">{t.title}</a>
                    {t.titleZh ? <span class="zh" lang="zh-Hant">{t.titleZh}</span> : <span class="missing">No Chinese title</span>}
                  </td>
                  <td>{priceLabel(t.price)}</td>
                  <td>
                    <div class="badges">
                      {!t.published && <span class="badge badge-draft">Draft</span>}
                      {t.featured && <span class="badge badge-featured">Featured</span>}
                      {t.comingSoon && <span class="badge">Coming soon</span>}
                    </div>
                  </td>
                  <td class="muted">{t.updatedAt.slice(0, 10)}</td>
                  <td>
                    {siteUrl && t.published && (
                      <a href={`${siteUrl.replace(/\/+$/, '')}/tours/${t.slug}`} target="_blank" rel="noreferrer">View</a>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )
    })}
  </Layout>
)

const FieldError: FC<{ errors: FieldErrors; name: string }> = ({ errors, name }) =>
  errors[name] ? <p class="field-error">{errors[name]}</p> : null

/** English and Chinese inputs for one field, side by side */
const Pair: FC<{
  name: string
  label: string
  values: TourValues
  errors: FieldErrors
  rows?: number
  hint?: string
  zhHint?: string
  required?: boolean
}> = ({ name, label, values, errors, rows, hint, zhHint, required }) => {
  const input = (field: string, lang?: string) =>
    rows ? (
      <textarea name={field} rows={rows} lang={lang}>{str(values[field])}</textarea>
    ) : (
      <input type="text" name={field} value={str(values[field])} lang={lang} required={required && !lang} />
    )
  return (
    <div class="pair">
      <label class="field">
        <span>{label} <em class="lang">EN</em></span>
        {input(name)}
        {hint && <small>{hint}</small>}
        <FieldError errors={errors} name={name} />
      </label>
      <label class="field">
        <span>{label} <em class="lang">中文</em></span>
        {input(`${name}Zh`, 'zh-Hant')}
        <small>{zhHint ?? 'Optional. The English is shown when this is empty.'}</small>
        <FieldError errors={errors} name={`${name}Zh`} />
      </label>
    </div>
  )
}

/** Hidden media key plus preview; admin.js handles picking, resizing and uploading */
const ImageField: FC<{ name: string; value: unknown; maxSize: number; label?: string }> = ({ name, value, maxSize, label }) => {
  const key = str(value)
  return (
    <div class="image-field" data-max-size={String(maxSize)}>
      <input type="hidden" name={name} value={key} />
      <img class="preview" src={key ? `/media/${key}` : ''} alt="" hidden={!key} />
      <div class="image-actions">
        <label class="btn btn-small">
          {label ?? 'Choose photo'}
          <input type="file" accept="image/jpeg,image/png,image/webp" hidden />
        </label>
        <button type="button" class="btn btn-small btn-ghost" data-remove-image hidden={!key}>Remove</button>
        <span class="status" aria-live="polite" />
      </div>
    </div>
  )
}

const TastingRow: FC<{ tasting?: Partial<Tasting> }> = ({ tasting = {} }) => (
  <div class="tasting-row">
    <ImageField name="tastingImage" value={tasting.image} maxSize={800} label="Photo" />
    <label class="field">
      <span>Name <em class="lang">EN</em></span>
      <input type="text" name="tastingName" value={tasting.name ?? ''} />
    </label>
    <label class="field">
      <span>Name <em class="lang">中文</em></span>
      <input type="text" name="tastingNameZh" value={tasting.nameZh ?? ''} lang="zh-Hant" />
    </label>
    <button type="button" class="btn btn-small btn-ghost" data-remove-row>Remove</button>
  </div>
)

const Check: FC<{ name: string; label: string; values: TourValues; hint?: string }> = ({ name, label, values, hint }) => (
  <label class="check">
    <input type="checkbox" name={name} checked={values[name] === true} />
    <span>{label}{hint && <small>{hint}</small>}</span>
  </label>
)

export const TourFormPage: FC<{
  tour?: Tour
  values: TourValues
  errors?: FieldErrors
  notice?: string
  siteUrl?: string
}> = ({ tour, values, errors = {}, notice, siteUrl }) => {
  const hasErrors = Object.keys(errors).length > 0
  const tastings = Array.isArray(values.tastings) ? (values.tastings as Tasting[]) : []
  return (
    <Layout title={tour ? tour.title : 'New tour'} signedIn>
      <div class="page-head">
        <h1>{tour ? tour.title : 'New tour'}</h1>
        <a href="/admin/tours">← All tours</a>
      </div>
      {notice && <p class="alert alert-ok">{notice}</p>}
      {hasErrors && <p class="alert alert-error">Please fix the fields marked below.</p>}

      <form method="post" action={tour ? `/admin/tours/${tour.id}` : '/admin/tours'} class="tour-form" data-new={tour ? undefined : ''}>
        <section class="card">
          <h2>Basics</h2>
          <Pair name="title" label="Title" values={values} errors={errors} required />
          <div class="grid">
            <label class="field">
              <span>Slug</span>
              <input type="text" name="slug" value={str(values.slug)} placeholder="made from the title if empty" />
              <small>The web address: /tours/<strong>slug</strong></small>
              <FieldError errors={errors} name="slug" />
            </label>
            <label class="field">
              <span>Category</span>
              <select name="category">
                {CATEGORIES.map((c) => (
                  <option value={c.key} selected={values.category === c.key}>{c.label}</option>
                ))}
              </select>
              <small>Which row the tour appears in on the website</small>
              <FieldError errors={errors} name="category" />
            </label>
            <label class="field">
              <span>Price (USD)</span>
              <input type="number" name="price" min="0" step="0.01" value={numberText(values.price)} />
              <small>0 = free (tips welcome). Empty = price on request.</small>
              <FieldError errors={errors} name="price" />
            </label>
            <label class="field">
              <span>Position</span>
              <input type="number" name="sortOrder" step="1" value={numberText(values.sortOrder)} />
              <small>Lower numbers come first in their row</small>
              <FieldError errors={errors} name="sortOrder" />
            </label>
          </div>
          <Pair name="location" label="Location" values={values} errors={errors} hint="e.g. Taipei" zhHint="e.g. 台北" />
          <div class="checks">
            <Check name="published" label="Published" values={values} hint="Untick to keep it as a draft only you can see here" />
            <Check name="featured" label="Featured" values={values} hint="Shown on the home page" />
            <Check name="comingSoon" label="Details coming soon" values={values} hint="Listed with an Ask on WhatsApp button instead of booking" />
          </div>
        </section>

        <section class="card">
          <h2>Main image</h2>
          <ImageField name="mainImage" value={values.mainImage} maxSize={1600} />
          <FieldError errors={errors} name="mainImage" />
        </section>

        <section class="card">
          <h2>When and where</h2>
          <Pair name="startTime" label="Start time" values={values} errors={errors} hint="e.g. 7:00 PM" zhHint="e.g. 晚上 7:00" />
          <Pair name="duration" label="Duration" values={values} errors={errors} hint="e.g. About 2.5 hours" zhHint="e.g. 約 2.5 小時" />
          <Pair name="meetingPoint" label="Meeting point" values={values} errors={errors} hint="e.g. Dongmen MRT Station, Exit 3" />
        </section>

        <section class="card">
          <h2>Description</h2>
          <Pair name="description" label="Short description" values={values} errors={errors} rows={2} hint="One or two sentences for the tour card" />
          <Pair name="body" label="Full description" values={values} errors={errors} rows={8} hint="Leave a blank line between paragraphs" />
          <div class="pair">
            <label class="field">
              <span>Highlights <em class="lang">EN</em></span>
              <textarea name="highlights" rows={5}>{lines(values.highlights)}</textarea>
              <small>One per line</small>
              <FieldError errors={errors} name="highlights" />
            </label>
            <label class="field">
              <span>Highlights <em class="lang">中文</em></span>
              <textarea name="highlightsZh" rows={5} lang="zh-Hant">{lines(values.highlightsZh)}</textarea>
              <small>One per line, in the same order as the English</small>
              <FieldError errors={errors} name="highlightsZh" />
            </label>
          </div>
          <Pair name="note" label="Note" values={values} errors={errors} hint="e.g. Tips are welcome." />
        </section>

        <section class="card">
          <h2>Tastings / stops</h2>
          <FieldError errors={errors} name="tastings" />
          <div class="tastings" data-tastings>
            {tastings.map((t) => <TastingRow tasting={t} />)}
          </div>
          <template id="tasting-template">
            <TastingRow />
          </template>
          <button type="button" class="btn btn-small" data-add-tasting>Add tasting</button>
        </section>

        <div class="form-actions">
          <button type="submit" class="btn btn-primary">{tour ? 'Save changes' : 'Create tour'}</button>
          {tour && siteUrl && tour.published && (
            <a href={`${siteUrl.replace(/\/+$/, '')}/tours/${tour.slug}`} target="_blank" rel="noreferrer">View on site</a>
          )}
        </div>
      </form>

      {tour && (
        <form method="post" action={`/admin/tours/${tour.id}/delete`} class="danger-zone" data-confirm={`Delete "${tour.title}"? This cannot be undone.`}>
          <button type="submit" class="btn btn-danger">Delete tour</button>
        </form>
      )}
    </Layout>
  )
}
