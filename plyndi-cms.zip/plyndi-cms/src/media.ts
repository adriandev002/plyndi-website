// Images live in the MEDIA R2 bucket under random, never-reused keys, so they can be cached forever.

import type { Context } from 'hono'
import type { AppEnv } from './env'
import { MEDIA_KEY_PATTERN } from './tours'

const MAX_BYTES = 5 * 1024 * 1024

const TYPES: Record<string, { ext: string; matches: (b: Uint8Array) => boolean }> = {
  'image/jpeg': { ext: 'jpg', matches: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  'image/png': { ext: 'png', matches: (b) => b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 },
  'image/webp': {
    ext: 'webp',
    matches: (b) => String.fromCharCode(...b.slice(0, 4)) === 'RIFF' && String.fromCharCode(...b.slice(8, 12)) === 'WEBP',
  },
}

export function mediaBase(c: Context<AppEnv>) {
  return (c.env.PUBLIC_URL || new URL(c.req.url).origin).replace(/\/+$/, '')
}

/** POST body is the raw image; answers { key, url } */
export async function uploadMedia(c: Context<AppEnv>) {
  const contentType = (c.req.header('content-type') ?? '').split(';')[0].trim().toLowerCase()
  const type = TYPES[contentType]
  if (!type) return c.json({ error: 'Upload a JPEG, PNG or WebP image' }, 415)

  const declared = Number(c.req.header('content-length') ?? 0)
  if (declared > MAX_BYTES) return c.json({ error: 'Images must be under 5 MB' }, 413)
  const bytes = new Uint8Array(await c.req.arrayBuffer())
  if (bytes.byteLength === 0) return c.json({ error: 'The image is empty' }, 400)
  if (bytes.byteLength > MAX_BYTES) return c.json({ error: 'Images must be under 5 MB' }, 413)
  if (!type.matches(bytes)) return c.json({ error: `The file is not a valid ${type.ext.toUpperCase()} image` }, 415)

  const key = `${crypto.randomUUID()}.${type.ext}`
  await c.env.MEDIA.put(key, bytes, { httpMetadata: { contentType } })
  return c.json({ key, url: `${mediaBase(c)}/media/${key}` }, 201)
}

export async function serveMedia(c: Context<AppEnv>) {
  const key = c.req.param('key') ?? ''
  if (!MEDIA_KEY_PATTERN.test(key)) return c.notFound()

  const object = await c.env.MEDIA.get(key)
  if (!object) return c.notFound()

  const headers = new Headers()
  object.writeHttpMetadata(headers)
  headers.set('etag', object.httpEtag)
  headers.set('cache-control', 'public, max-age=31536000, immutable')
  headers.set('x-content-type-options', 'nosniff')
  if (c.req.header('if-none-match') === object.httpEtag) return new Response(null, { status: 304, headers })
  return new Response(object.body, { headers })
}
