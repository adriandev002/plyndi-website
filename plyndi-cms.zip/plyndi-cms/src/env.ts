export interface Env {
  DB: D1Database
  MEDIA: R2Bucket
  /** Admin login password (secret) */
  ADMIN_PASSWORD?: string
  /** Key for signing the admin session cookie (secret) */
  SESSION_SECRET?: string
  /** Public website, for "View on site" links */
  SITE_URL?: string
  /** Base URL for image links in API responses; defaults to this Worker's URL */
  PUBLIC_URL?: string
}

export type AppEnv = { Bindings: Env }
