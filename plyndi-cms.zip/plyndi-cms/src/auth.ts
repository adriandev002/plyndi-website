// Admin sign-in: one shared password, a signed session cookie, and a cap on failed attempts per IP.

import type { Context, MiddlewareHandler } from 'hono'
import { deleteCookie, getSignedCookie, setSignedCookie } from 'hono/cookie'
import type { AppEnv, Env } from './env'

const COOKIE = 'cms_session'
const SESSION_SECONDS = 7 * 24 * 60 * 60
const MAX_FAILURES = 10
const FAILURE_WINDOW_MS = 15 * 60 * 1000
const MIN_PASSWORD_LENGTH = 12

/** Why the admin can't be used yet, or null when it is configured */
export function configProblem(env: Env): string | null {
  if (!env.ADMIN_PASSWORD || !env.SESSION_SECRET) return 'Set the ADMIN_PASSWORD and SESSION_SECRET secrets to use the admin.'
  if (env.ADMIN_PASSWORD.length < MIN_PASSWORD_LENGTH) return `ADMIN_PASSWORD must be at least ${MIN_PASSWORD_LENGTH} characters.`
  return null
}

// Changing the password signs everyone out, because it is part of the signing key
const signingKey = (env: Env) => `${env.SESSION_SECRET}:${env.ADMIN_PASSWORD}`

async function sha256(text: string) {
  return crypto.subtle.digest('SHA-256', new TextEncoder().encode(text))
}

async function passwordMatches(env: Env, attempt: string) {
  const [a, b] = await Promise.all([sha256(attempt), sha256(env.ADMIN_PASSWORD!)])
  return crypto.subtle.timingSafeEqual(a, b)
}

const clientIp = (c: Context) => c.req.header('cf-connecting-ip') ?? 'unknown'

export type LoginResult = 'ok' | 'wrong-password' | 'locked' | 'not-configured'

/** Checks the password and, when it matches, sets the session cookie */
export async function logIn(c: Context<AppEnv>, password: string): Promise<LoginResult> {
  const env = c.env
  if (configProblem(env)) return 'not-configured'

  const ip = clientIp(c)
  const now = Date.now()
  const row = await env.DB.prepare('SELECT failures, first_at FROM login_attempts WHERE ip = ?')
    .bind(ip)
    .first<{ failures: number; first_at: number }>()
  const windowOpen = row && now - row.first_at < FAILURE_WINDOW_MS
  if (windowOpen && row.failures >= MAX_FAILURES) return 'locked'

  if (!(await passwordMatches(env, password))) {
    await env.DB.prepare(
      `INSERT INTO login_attempts (ip, failures, first_at) VALUES (?1, 1, ?2)
       ON CONFLICT (ip) DO UPDATE SET
         failures = CASE WHEN ?2 - first_at < ?3 THEN failures + 1 ELSE 1 END,
         first_at = CASE WHEN ?2 - first_at < ?3 THEN first_at ELSE ?2 END`,
    )
      .bind(ip, now, FAILURE_WINDOW_MS)
      .run()
    return 'wrong-password'
  }

  if (row) await env.DB.prepare('DELETE FROM login_attempts WHERE ip = ?').bind(ip).run()
  const expires = now + SESSION_SECONDS * 1000
  await setSignedCookie(c, COOKIE, String(expires), signingKey(env), {
    httpOnly: true,
    secure: true,
    sameSite: 'Lax',
    path: '/',
    maxAge: SESSION_SECONDS,
  })
  return 'ok'
}

export function logOut(c: Context<AppEnv>) {
  deleteCookie(c, COOKIE, { path: '/', secure: true })
}

export async function isLoggedIn(c: Context<AppEnv>) {
  if (configProblem(c.env)) return false
  const value = await getSignedCookie(c, signingKey(c.env), COOKIE)
  return typeof value === 'string' && Number(value) > Date.now()
}

/** Lets signed-in requests through; others get `onDenied` */
export function requireLogin(onDenied: (c: Context<AppEnv>) => Response | Promise<Response>): MiddlewareHandler<AppEnv> {
  return async (c, next) => {
    if (!(await isLoggedIn(c))) return onDenied(c)
    await next()
  }
}
