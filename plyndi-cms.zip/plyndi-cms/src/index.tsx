import { Hono, type Context } from 'hono'
import { cors } from 'hono/cors'
import { csrf } from 'hono/csrf'
import { html } from 'hono/html'
import { HTTPException } from 'hono/http-exception'
import type { JSX } from 'hono/jsx/jsx-runtime'
import { secureHeaders } from 'hono/secure-headers'
import { configProblem, isLoggedIn, logIn, logOut, requireLogin } from './auth'
import type { AppEnv } from './env'
import { formToTour } from './admin/form'
import { LoginPage, NEW_TOUR, TourFormPage, ToursPage } from './admin/views'
import { mediaBase, serveMedia, uploadMedia } from './media'
import {
  SlugTakenError,
  createTour,
  deleteTour,
  getTourById,
  getTourBySlug,
  listTours,
  toPublicTour,
  updateTour,
  validateTour,
  type TourInput,
} from './tours'

const app = new Hono<AppEnv>()

app.get('/', (c) => c.redirect('/admin/tours'))

// ---------------------------------------------------------------------------
// Public, read-only API for the website. Only published tours.

app.use('/api/v1/*', cors({ origin: '*', allowMethods: ['GET'] }))

app.get('/api/v1/tours', async (c) => {
  const featured = ['1', 'true'].includes(c.req.query('featured') ?? '')
  const tours = await listTours(c.env.DB, { published: true, featured })
  c.header('cache-control', 'public, max-age=30')
  return c.json({ tours: tours.map((t) => toPublicTour(t, mediaBase(c))) })
})

app.get('/api/v1/tours/:slug', async (c) => {
  const tour = await getTourBySlug(c.env.DB, c.req.param('slug'), { published: true })
  if (!tour) return c.json({ error: 'Tour not found' }, 404)
  c.header('cache-control', 'public, max-age=30')
  return c.json({ tour: toPublicTour(tour, mediaBase(c)) })
})

app.get('/media/:key', serveMedia)

// ---------------------------------------------------------------------------
// Admin JSON API, used by the admin page's image uploads and by the scripts in /scripts

const apiGuard = requireLogin((c) => c.json({ error: 'Sign in first' }, 401))

app.post('/api/admin/login', async (c) => {
  const body = await c.req.json<{ password?: unknown }>().catch(() => ({ password: undefined }))
  const result = await logIn(c, typeof body.password === 'string' ? body.password : '')
  if (result === 'ok') return c.json({ ok: true })
  if (result === 'locked') return c.json({ error: 'Too many failed attempts. Try again in 15 minutes.' }, 429)
  if (result === 'not-configured') return c.json({ error: configProblem(c.env) }, 503)
  return c.json({ error: 'Wrong password' }, 401)
})

app.get('/api/admin/tours', apiGuard, async (c) => {
  return c.json({ tours: await listTours(c.env.DB) })
})

/** Creates or replaces the tour with this slug. `createdAt` (ISO date) is kept when creating, for ordering. */
app.put('/api/admin/tours/:slug', apiGuard, async (c) => {
  const body = await c.req.json<Record<string, unknown>>().catch(() => null)
  if (!body || typeof body !== 'object') return c.json({ error: 'Send the tour as JSON' }, 400)

  const result = validateTour({ ...body, slug: c.req.param('slug') })
  if (!result.ok) return c.json({ error: 'Invalid tour', fields: result.errors }, 422)

  const existing = await getTourBySlug(c.env.DB, result.tour.slug)
  if (existing) return c.json({ tour: await updateTour(c.env.DB, existing.id, result.tour), created: false })

  const createdAt = typeof body.createdAt === 'string' && !Number.isNaN(Date.parse(body.createdAt))
    ? new Date(body.createdAt).toISOString()
    : undefined
  return c.json({ tour: await createTour(c.env.DB, result.tour, createdAt), created: true }, 201)
})

app.post('/api/admin/media', apiGuard, uploadMedia)

// ---------------------------------------------------------------------------
// Admin pages

app.use(
  '/admin/*',
  secureHeaders({
    contentSecurityPolicy: {
      defaultSrc: ["'self'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      formAction: ["'self'"],
      frameAncestors: ["'none'"],
      baseUri: ["'none'"],
      objectSrc: ["'none'"],
    },
    xFrameOptions: 'DENY',
    referrerPolicy: 'same-origin',
  }),
  csrf(),
)

const page = (c: Context<AppEnv>, body: JSX.Element, status: 200 | 401 | 404 | 422 | 429 | 503 = 200) =>
  c.html(html`<!doctype html>${body}`, status)

const pageGuard = requireLogin((c) => c.redirect('/admin/login'))

app.get('/admin', (c) => c.redirect('/admin/tours'))

app.get('/admin/login', async (c) => {
  if (await isLoggedIn(c)) return c.redirect('/admin/tours')
  const problem = configProblem(c.env)
  return page(c, <LoginPage error={problem ?? undefined} />, problem ? 503 : 200)
})

app.post('/admin/login', async (c) => {
  const form = await c.req.formData()
  const password = form.get('password')
  const result = await logIn(c, typeof password === 'string' ? password : '')
  if (result === 'ok') return c.redirect('/admin/tours')
  if (result === 'locked') return page(c, <LoginPage error="Too many failed attempts. Try again in 15 minutes." />, 429)
  if (result === 'not-configured') return page(c, <LoginPage error={configProblem(c.env)!} />, 503)
  return page(c, <LoginPage error="Wrong password" />, 401)
})

app.post('/admin/logout', (c) => {
  logOut(c)
  return c.redirect('/admin/login')
})

const NOTICES: Record<string, string> = { saved: 'Saved.', deleted: 'Tour deleted.' }
const notice = (c: Context<AppEnv>) => NOTICES[c.req.query('notice') ?? '']

app.get('/admin/tours', pageGuard, async (c) => {
  const tours = await listTours(c.env.DB)
  return page(c, <ToursPage tours={tours} siteUrl={c.env.SITE_URL} notice={notice(c)} />)
})

app.get('/admin/tours/new', pageGuard, (c) => page(c, <TourFormPage values={NEW_TOUR} />))

/** Validates the submitted form, saves it with `save`, and re-shows the form with errors when needed */
async function submitTour(
  c: Context<AppEnv>,
  existing: Awaited<ReturnType<typeof getTourById>> | undefined,
  save: (tour: TourInput) => Promise<{ id: string } | null>,
) {
  const values = formToTour(await c.req.formData())
  const result = validateTour(values)
  let errors = result.ok ? {} : result.errors
  if (result.ok) {
    try {
      const saved = await save(result.tour)
      if (!saved) return c.notFound()
      return c.redirect(`/admin/tours/${saved.id}?notice=saved`)
    } catch (err) {
      if (!(err instanceof SlugTakenError)) throw err
      errors = { slug: err.message }
    }
  }
  return page(c, <TourFormPage tour={existing ?? undefined} values={values} errors={errors} siteUrl={c.env.SITE_URL} />, 422)
}

app.post('/admin/tours', pageGuard, (c) => submitTour(c, undefined, (tour) => createTour(c.env.DB, tour)))

app.get('/admin/tours/:id', pageGuard, async (c) => {
  const tour = await getTourById(c.env.DB, c.req.param('id'))
  if (!tour) return c.notFound()
  return page(c, <TourFormPage tour={tour} values={tour as unknown as Record<string, unknown>} notice={notice(c)} siteUrl={c.env.SITE_URL} />)
})

app.post('/admin/tours/:id', pageGuard, async (c) => {
  const existing = await getTourById(c.env.DB, c.req.param('id'))
  if (!existing) return c.notFound()
  return submitTour(c, existing, (tour) => updateTour(c.env.DB, existing.id, tour))
})

app.post('/admin/tours/:id/delete', pageGuard, async (c) => {
  await deleteTour(c.env.DB, c.req.param('id'))
  return c.redirect('/admin/tours?notice=deleted')
})

app.notFound((c) => (c.req.path.startsWith('/api/') ? c.json({ error: 'Not found' }, 404) : c.text('Not found', 404)))

app.onError((err, c) => {
  if (err instanceof HTTPException) return err.getResponse()
  console.error(err)
  return c.req.path.startsWith('/api/') ? c.json({ error: 'Something went wrong' }, 500) : c.text('Something went wrong', 500)
})

export default app
