// Tour content: the shape editors write, validation, and D1 storage.

export const CATEGORIES = [
  { key: 'free', label: 'Free Tours' },
  { key: 'food', label: 'Food Tours' },
  { key: 'night', label: 'Night / Drink Tours' },
  { key: 'hiking', label: 'Hiking Tours' },
  { key: 'special', label: 'Special Request Tours' },
] as const

export type Category = (typeof CATEGORIES)[number]['key']

export interface Tasting {
  name: string
  nameZh: string | null
  /** Key in the MEDIA bucket */
  image: string | null
}

/** A tour as editors write it. Every visitor-facing text has an optional Chinese (…Zh) version. */
export interface TourInput {
  slug: string
  category: Category
  title: string
  titleZh: string | null
  location: string | null
  locationZh: string | null
  /** 0 = free, null = price on request */
  price: number | null
  duration: string | null
  durationZh: string | null
  meetingPoint: string | null
  meetingPointZh: string | null
  startTime: string | null
  startTimeZh: string | null
  /** Key in the MEDIA bucket */
  mainImage: string | null
  featured: boolean
  comingSoon: boolean
  /** One-line summary for cards */
  description: string | null
  descriptionZh: string | null
  /** Full description, blank line between paragraphs */
  body: string | null
  bodyZh: string | null
  highlights: string[]
  highlightsZh: string[]
  tastings: Tasting[]
  note: string | null
  noteZh: string | null
  /** Drafts are only visible in the admin */
  published: boolean
  /** Lower comes first within a category; ties go to the newest */
  sortOrder: number
}

export interface Tour extends TourInput {
  id: string
  createdAt: string
  updatedAt: string
}

// ---------------------------------------------------------------------------
// Validation

/** Longest allowed value for each text field; the …Zh twin gets the same limit */
export const TEXT_LIMITS = {
  title: 200,
  location: 100,
  duration: 100,
  meetingPoint: 200,
  startTime: 100,
  description: 500,
  body: 10_000,
  note: 500,
} as const

const MAX_LIST_ITEMS = 30
const MAX_LIST_ITEM_LENGTH = 300
const SLUG_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/
export const MEDIA_KEY_PATTERN = /^[a-z0-9-]+\.(?:jpg|png|webp)$/

export type FieldErrors = Record<string, string>
export type Validation = { ok: true; tour: TourInput } | { ok: false; errors: FieldErrors }

export function slugify(text: string) {
  return text
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 96)
    .replace(/-+$/, '')
}

/** Checks and cleans a tour from the admin form or the admin API. Empty text becomes null. */
export function validateTour(raw: unknown): Validation {
  const src = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  const errors: FieldErrors = {}

  const text = (key: string, max: number): string | null => {
    const v = src[key]
    if (v == null) return null
    if (typeof v !== 'string') {
      errors[key] = 'Must be text'
      return null
    }
    const t = v.replace(/\r\n?/g, '\n').trim()
    if (t.length > max) errors[key] = `Keep this under ${max.toLocaleString('en-US')} characters`
    return t || null
  }

  const list = (key: string): string[] => {
    const v = src[key]
    if (v == null) return []
    if (!Array.isArray(v) || v.some((item) => typeof item !== 'string')) {
      errors[key] = 'Must be a list of text'
      return []
    }
    const items = (v as string[]).map((s) => s.trim()).filter(Boolean)
    if (items.length > MAX_LIST_ITEMS) errors[key] = `Use at most ${MAX_LIST_ITEMS} items`
    else if (items.some((s) => s.length > MAX_LIST_ITEM_LENGTH)) errors[key] = `Keep each item under ${MAX_LIST_ITEM_LENGTH} characters`
    return items
  }

  const flag = (key: string, fallback: boolean): boolean => {
    const v = src[key]
    if (v == null) return fallback
    if (typeof v !== 'boolean') errors[key] = 'Must be true or false'
    return v === true
  }

  const image = (key: string, v: unknown): string | null => {
    if (v == null || v === '') return null
    if (typeof v !== 'string' || !MEDIA_KEY_PATTERN.test(v)) {
      errors[key] = 'Unknown image. Upload it again.'
      return null
    }
    return v
  }

  const texts = {} as Record<string, string | null>
  for (const [key, max] of Object.entries(TEXT_LIMITS)) {
    texts[key] = text(key, max)
    texts[`${key}Zh`] = text(`${key}Zh`, max)
  }
  if (!texts.title) errors.title = 'Give the tour an English title'

  const category = src.category
  if (!CATEGORIES.some((c) => c.key === category)) errors.category = 'Choose a category'

  let slug = typeof src.slug === 'string' ? src.slug.trim().toLowerCase() : ''
  if (!slug && texts.title) slug = slugify(texts.title)
  if (!slug) errors.slug ??= 'Add a slug, e.g. dongmen-street-food-tour'
  else if (slug.length > 96 || !SLUG_PATTERN.test(slug)) errors.slug = 'Use lowercase letters, numbers and dashes only'

  let price: number | null = null
  if (src.price != null && src.price !== '') {
    const n = typeof src.price === 'number' ? src.price : Number.NaN
    if (!Number.isFinite(n) || n < 0 || n > 100_000) errors.price = 'Use a number from 0 (free) upwards, or leave empty for price on request'
    else price = Math.round(n * 100) / 100
  }

  let sortOrder = 0
  if (src.sortOrder != null && src.sortOrder !== '') {
    if (!Number.isInteger(src.sortOrder) || Math.abs(src.sortOrder as number) > 1_000_000) errors.sortOrder = 'Use a whole number'
    else sortOrder = src.sortOrder as number
  }

  const tastings: Tasting[] = []
  if (src.tastings != null) {
    if (!Array.isArray(src.tastings)) errors.tastings = 'Must be a list'
    else {
      for (const row of src.tastings as unknown[]) {
        const r = (row && typeof row === 'object' ? row : {}) as Record<string, unknown>
        const name = typeof r.name === 'string' ? r.name.trim() : ''
        const nameZh = typeof r.nameZh === 'string' ? r.nameZh.trim() : ''
        const img = image('tastings', r.image)
        if (!name && !nameZh && !img) continue
        if (!name) errors.tastings = 'Every tasting needs an English name'
        if (name.length > MAX_LIST_ITEM_LENGTH || nameZh.length > MAX_LIST_ITEM_LENGTH) errors.tastings = 'Keep tasting names short'
        tastings.push({ name, nameZh: nameZh || null, image: img })
      }
      if (tastings.length > MAX_LIST_ITEMS) errors.tastings = `Use at most ${MAX_LIST_ITEMS} tastings`
    }
  }

  const tour: TourInput = {
    slug,
    category: category as Category,
    title: texts.title ?? '',
    titleZh: texts.titleZh,
    location: texts.location,
    locationZh: texts.locationZh,
    price,
    duration: texts.duration,
    durationZh: texts.durationZh,
    meetingPoint: texts.meetingPoint,
    meetingPointZh: texts.meetingPointZh,
    startTime: texts.startTime,
    startTimeZh: texts.startTimeZh,
    mainImage: image('mainImage', src.mainImage),
    featured: flag('featured', false),
    comingSoon: flag('comingSoon', false),
    description: texts.description,
    descriptionZh: texts.descriptionZh,
    body: texts.body,
    bodyZh: texts.bodyZh,
    highlights: list('highlights'),
    highlightsZh: list('highlightsZh'),
    tastings,
    note: texts.note,
    noteZh: texts.noteZh,
    published: flag('published', true),
    sortOrder,
  }

  return Object.keys(errors).length > 0 ? { ok: false, errors } : { ok: true, tour }
}

// ---------------------------------------------------------------------------
// Storage

const COLUMNS: Record<keyof TourInput, string> = {
  slug: 'slug',
  category: 'category',
  title: 'title',
  titleZh: 'title_zh',
  location: 'location',
  locationZh: 'location_zh',
  price: 'price',
  duration: 'duration',
  durationZh: 'duration_zh',
  meetingPoint: 'meeting_point',
  meetingPointZh: 'meeting_point_zh',
  startTime: 'start_time',
  startTimeZh: 'start_time_zh',
  mainImage: 'main_image',
  featured: 'featured',
  comingSoon: 'coming_soon',
  description: 'description',
  descriptionZh: 'description_zh',
  body: 'body',
  bodyZh: 'body_zh',
  highlights: 'highlights',
  highlightsZh: 'highlights_zh',
  tastings: 'tastings',
  note: 'note',
  noteZh: 'note_zh',
  published: 'published',
  sortOrder: 'sort_order',
}

const FIELDS = Object.keys(COLUMNS) as (keyof TourInput)[]
const BOOLEAN_FIELDS = new Set<keyof TourInput>(['featured', 'comingSoon', 'published'])
const JSON_FIELDS = new Set<keyof TourInput>(['highlights', 'highlightsZh', 'tastings'])

function toColumn(field: keyof TourInput, value: unknown) {
  if (BOOLEAN_FIELDS.has(field)) return value ? 1 : 0
  if (JSON_FIELDS.has(field)) return JSON.stringify(value)
  return value
}

function fromRow(row: Record<string, unknown>): Tour {
  const tour = { id: row.id, createdAt: row.created_at, updatedAt: row.updated_at } as Record<string, unknown>
  for (const field of FIELDS) {
    const value = row[COLUMNS[field]]
    if (BOOLEAN_FIELDS.has(field)) tour[field] = value === 1
    else if (JSON_FIELDS.has(field)) tour[field] = JSON.parse((value as string) || '[]')
    else tour[field] = value ?? null
  }
  return tour as unknown as Tour
}

export class SlugTakenError extends Error {
  constructor(slug: string) {
    super(`Another tour already uses the slug "${slug}"`)
  }
}

async function write<T>(slug: string, run: () => Promise<T>): Promise<T> {
  try {
    return await run()
  } catch (err) {
    if (String(err).includes('UNIQUE constraint failed: tours.slug')) throw new SlugTakenError(slug)
    throw err
  }
}

const ORDER = 'ORDER BY sort_order ASC, created_at DESC'

export async function listTours(db: D1Database, opts: { published?: boolean; featured?: boolean } = {}): Promise<Tour[]> {
  const where = [opts.published && 'published = 1', opts.featured && 'featured = 1'].filter(Boolean)
  const sql = `SELECT * FROM tours ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ${ORDER}`
  const { results } = await db.prepare(sql).all<Record<string, unknown>>()
  return results.map(fromRow)
}

export async function getTourById(db: D1Database, id: string): Promise<Tour | null> {
  const row = await db.prepare('SELECT * FROM tours WHERE id = ?').bind(id).first<Record<string, unknown>>()
  return row ? fromRow(row) : null
}

export async function getTourBySlug(db: D1Database, slug: string, opts: { published?: boolean } = {}): Promise<Tour | null> {
  const sql = `SELECT * FROM tours WHERE slug = ?${opts.published ? ' AND published = 1' : ''}`
  const row = await db.prepare(sql).bind(slug).first<Record<string, unknown>>()
  return row ? fromRow(row) : null
}

export async function createTour(db: D1Database, input: TourInput, createdAt = new Date().toISOString()): Promise<Tour> {
  const id = crypto.randomUUID()
  const now = new Date().toISOString()
  const columns = ['id', ...FIELDS.map((f) => COLUMNS[f]), 'created_at', 'updated_at']
  const values = [id, ...FIELDS.map((f) => toColumn(f, input[f])), createdAt, now]
  const sql = `INSERT INTO tours (${columns.join(', ')}) VALUES (${columns.map(() => '?').join(', ')})`
  await write(input.slug, () => db.prepare(sql).bind(...values).run())
  return (await getTourById(db, id))!
}

/** Returns null when there is no tour with this id */
export async function updateTour(db: D1Database, id: string, input: TourInput): Promise<Tour | null> {
  const sets = FIELDS.map((f) => `${COLUMNS[f]} = ?`)
  const values = FIELDS.map((f) => toColumn(f, input[f]))
  const sql = `UPDATE tours SET ${sets.join(', ')}, updated_at = ? WHERE id = ?`
  const { meta } = await write(input.slug, () => db.prepare(sql).bind(...values, new Date().toISOString(), id).run())
  return meta.changes > 0 ? getTourById(db, id) : null
}

export async function deleteTour(db: D1Database, id: string): Promise<boolean> {
  const { meta } = await db.prepare('DELETE FROM tours WHERE id = ?').bind(id).run()
  return meta.changes > 0
}

// ---------------------------------------------------------------------------
// Public API shape

function mediaUrl(base: string, key: string | null) {
  return key ? `${base}/media/${key}` : null
}

/** A published tour as the website reads it: image keys become full URLs */
export function toPublicTour(tour: Tour, mediaBase: string) {
  const { published: _published, ...rest } = tour
  return {
    ...rest,
    mainImage: mediaUrl(mediaBase, tour.mainImage),
    tastings: tour.tastings.map((t) => ({ ...t, image: mediaUrl(mediaBase, t.image) })),
  }
}
