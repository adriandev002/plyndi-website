import { exports } from 'cloudflare:workers'
import { beforeAll, describe, expect, it } from 'vitest'
import { slugify, validateTour } from '../src/tours'

const ORIGIN = 'https://cms.test'
const PNG = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0])

const worker = (exports as unknown as { default: Fetcher }).default
const call = (path: string, init: RequestInit = {}) => worker.fetch(new Request(ORIGIN + path, { redirect: 'manual', ...init }))

let cookie = ''

async function login(password = 'correct horse battery staple', ip = '203.0.113.1') {
  return call('/api/admin/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'cf-connecting-ip': ip },
    body: JSON.stringify({ password }),
  })
}

/** Submits the admin tour form the way a browser would */
function postForm(path: string, fields: [string, string][], origin = ORIGIN) {
  return call(path, {
    method: 'POST',
    headers: { cookie, origin, 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(fields).toString(),
  })
}

const putTour = (slug: string, tour: Record<string, unknown>) =>
  call(`/api/admin/tours/${slug}`, {
    method: 'PUT',
    headers: { cookie, 'content-type': 'application/json' },
    body: JSON.stringify(tour),
  })

const publicTours = async (query = '') => ((await (await call(`/api/v1/tours${query}`)).json()) as { tours: any[] }).tours

beforeAll(async () => {
  const res = await login()
  expect(res.status).toBe(200)
  cookie = res.headers.get('set-cookie')!.split(';')[0]
})

describe('sign in', () => {
  it('sends signed-out visitors to the login page and rejects API calls', async () => {
    const page = await call('/admin/tours')
    expect(page.status).toBe(302)
    expect(page.headers.get('location')).toBe('/admin/login')
    expect((await call('/api/admin/tours')).status).toBe(401)
    expect((await call('/api/admin/tours', { headers: { cookie: 'cms_session=123.forged' } })).status).toBe(401)
  })

  it('rejects a wrong password and locks the IP after 10 failures', async () => {
    for (let i = 0; i < 10; i++) expect((await login('wrong password!!', '198.51.100.7')).status).toBe(401)
    expect((await login('wrong password!!', '198.51.100.7')).status).toBe(429)
    expect((await login(undefined, '198.51.100.7')).status).toBe(429)
    expect((await login(undefined, '198.51.100.8')).status).toBe(200)
  })

  it('signs in through the login form', async () => {
    const res = await call('/admin/login', {
      method: 'POST',
      headers: { origin: ORIGIN, 'content-type': 'application/x-www-form-urlencoded' },
      body: 'password=correct+horse+battery+staple',
    })
    expect(res.status).toBe(302)
    expect(res.headers.get('set-cookie')).toMatch(/cms_session=.+HttpOnly/i)
  })

  it('blocks form posts from other sites', async () => {
    const res = await postForm('/admin/tours', [['title', 'Sneaky'], ['category', 'food']], 'https://evil.example')
    expect(res.status).toBe(403)
  })
})

describe('tours', () => {
  it('creates a bilingual tour from the admin form and serves it on the public API', async () => {
    const res = await postForm('/admin/tours', [
      ['title', 'Dongmen Street Food Tour'],
      ['titleZh', '東門美食導覽'],
      ['slug', ''],
      ['category', 'food'],
      ['price', ''],
      ['sortOrder', '2'],
      ['location', 'Taipei'],
      ['locationZh', '台北'],
      ['startTime', '7:00 PM'],
      ['duration', 'About 2.5 hours'],
      ['meetingPoint', 'Dongmen MRT Station, Exit 3'],
      ['description', 'Five must-try finger foods.'],
      ['body', 'First paragraph.\r\n\r\nSecond paragraph.'],
      ['highlights', 'Five foods\r\n\r\nYour own portion\r\n'],
      ['highlightsZh', '五種小吃'],
      ['note', 'Tips are welcome.'],
      ['published', 'on'],
      ['featured', 'on'],
      ['mainImage', ''],
      ['tastingName', 'Xiao long bao'],
      ['tastingNameZh', '小籠包'],
      ['tastingImage', ''],
      ['tastingName', ''],
      ['tastingNameZh', ''],
      ['tastingImage', ''],
    ])
    expect(res.status).toBe(302)
    expect(res.headers.get('location')).toMatch(/^\/admin\/tours\/[0-9a-f-]{36}\?notice=saved$/)

    const detail = await call('/api/v1/tours/dongmen-street-food-tour')
    expect(detail.status).toBe(200)
    const { tour } = (await detail.json()) as { tour: any }
    expect(tour).toMatchObject({
      slug: 'dongmen-street-food-tour',
      category: 'food',
      title: 'Dongmen Street Food Tour',
      titleZh: '東門美食導覽',
      locationZh: '台北',
      price: null,
      featured: true,
      comingSoon: false,
      body: 'First paragraph.\n\nSecond paragraph.',
      bodyZh: null,
      highlights: ['Five foods', 'Your own portion'],
      highlightsZh: ['五種小吃'],
      tastings: [{ name: 'Xiao long bao', nameZh: '小籠包', image: null }],
      mainImage: null,
      sortOrder: 2,
    })
    expect(tour).not.toHaveProperty('published')

    const editPage = await call(res.headers.get('location')!, { headers: { cookie } })
    expect(editPage.status).toBe(200)
    expect(editPage.headers.get('content-security-policy')).toContain("script-src 'self'")
    expect(await editPage.text()).toContain('東門美食導覽')
  })

  it('re-shows the form with errors, escaping what was typed', async () => {
    const res = await postForm('/admin/tours', [
      ['title', ''],
      ['titleZh', '<script>alert(1)</script>'],
      ['category', 'food'],
      ['price', '-5'],
    ])
    expect(res.status).toBe(422)
    const page = await res.text()
    expect(page).toContain('Give the tour an English title')
    expect(page).toContain('Use a number from 0')
    expect(page).not.toContain('<script>alert(1)</script>')
    expect(page).toContain('&lt;script&gt;alert(1)&lt;/script&gt;')
  })

  it('refuses a slug that is already used', async () => {
    const res = await postForm('/admin/tours', [['title', 'Another'], ['slug', 'dongmen-street-food-tour'], ['category', 'food']])
    expect(res.status).toBe(422)
    expect(await res.text()).toContain('Another tour already uses the slug')
  })

  it('keeps drafts off the public API and filters featured tours', async () => {
    expect((await putTour('draft-tour', { title: 'Draft', category: 'night', published: false })).status).toBe(201)
    expect((await putTour('free-walk', { title: 'Free Walk', category: 'free', price: 0 })).status).toBe(201)

    const slugs = (await publicTours()).map((t) => t.slug)
    expect(slugs).toContain('free-walk')
    expect(slugs).not.toContain('draft-tour')
    expect((await call('/api/v1/tours/draft-tour')).status).toBe(404)

    const featured = (await publicTours('?featured=1')).map((t) => t.slug)
    expect(featured).toContain('dongmen-street-food-tour')
    expect(featured).not.toContain('free-walk')
  })

  it('upserts by slug through the admin API, keeping the id and the given createdAt', async () => {
    const first = await putTour('night-drinks', { title: 'Night Drinks', category: 'night', createdAt: '2025-01-02T03:04:05Z' })
    expect(first.status).toBe(201)
    const created = ((await first.json()) as any).tour

    const second = await putTour('night-drinks', { title: 'Night & Drink Tour', titleZh: '夜遊小酌', category: 'night', price: 35.5 })
    expect(second.status).toBe(200)
    const updated = ((await second.json()) as any).tour
    expect(updated.id).toBe(created.id)
    expect(updated.createdAt).toBe('2025-01-02T03:04:05.000Z')
    expect(updated).toMatchObject({ title: 'Night & Drink Tour', titleZh: '夜遊小酌', price: 35.5 })

    const invalid = await putTour('night-drinks', { title: 'x', category: 'museum' })
    expect(invalid.status).toBe(422)
    expect(((await invalid.json()) as any).fields.category).toBeDefined()
  })

  it('orders by position, then newest first', async () => {
    await putTour('order-b', { title: 'B', category: 'hiking', sortOrder: 1, createdAt: '2026-01-01T00:00:00Z' })
    await putTour('order-c', { title: 'C', category: 'hiking', sortOrder: 1, createdAt: '2026-02-01T00:00:00Z' })
    await putTour('order-a', { title: 'A', category: 'hiking', sortOrder: 0 })
    const hiking = (await publicTours()).filter((t) => t.category === 'hiking').map((t) => t.slug)
    expect(hiking).toEqual(['order-a', 'order-c', 'order-b'])
  })

  it('deletes a tour', async () => {
    const { tour } = (await (await putTour('to-delete', { title: 'Gone soon', category: 'special' })).json()) as any
    const res = await postForm(`/admin/tours/${tour.id}/delete`, [])
    expect(res.status).toBe(302)
    expect((await call('/api/v1/tours/to-delete')).status).toBe(404)
  })
})

describe('media', () => {
  it('stores an uploaded image and serves it with long caching', async () => {
    const upload = await call('/api/admin/media', { method: 'POST', headers: { cookie, 'content-type': 'image/png' }, body: PNG })
    expect(upload.status).toBe(201)
    const { key, url } = (await upload.json()) as { key: string; url: string }
    expect(key).toMatch(/^[0-9a-f-]{36}\.png$/)
    expect(url).toBe(`https://cms.example.com/media/${key}`)

    const image = await call(`/media/${key}`)
    expect(image.status).toBe(200)
    expect(image.headers.get('content-type')).toBe('image/png')
    expect(image.headers.get('cache-control')).toContain('immutable')
    expect(new Uint8Array(await image.arrayBuffer())).toEqual(PNG)

    await putTour('with-photo', { title: 'With photo', category: 'food', mainImage: key, tastings: [{ name: 'Tea', image: key }] })
    const { tour } = (await (await call('/api/v1/tours/with-photo')).json()) as any
    expect(tour.mainImage).toBe(url)
    expect(tour.tastings[0].image).toBe(url)
  })

  it('rejects uploads that are not images or not signed in', async () => {
    const svg = await call('/api/admin/media', { method: 'POST', headers: { cookie, 'content-type': 'image/svg+xml' }, body: '<svg/>' })
    expect(svg.status).toBe(415)
    const fake = await call('/api/admin/media', { method: 'POST', headers: { cookie, 'content-type': 'image/png' }, body: 'not a png' })
    expect(fake.status).toBe(415)
    const anon = await call('/api/admin/media', { method: 'POST', headers: { 'content-type': 'image/png' }, body: PNG })
    expect(anon.status).toBe(401)
    expect((await call('/media/..%2Fsecret')).status).toBe(404)
  })
})

describe('validateTour', () => {
  it('makes slugs from titles', () => {
    expect(slugify('  Café Night & Drink Tour! ')).toBe('cafe-night-drink-tour')
  })

  it('treats empty price as on request and 0 as free', () => {
    const base = { title: 'T', category: 'free' }
    expect(validateTour({ ...base, price: null })).toMatchObject({ ok: true, tour: { price: null } })
    expect(validateTour({ ...base, price: 0 })).toMatchObject({ ok: true, tour: { price: 0 } })
    expect(validateTour({ ...base, price: Number.NaN })).toMatchObject({ ok: false })
  })

  it('needs an English name for every tasting and a known image key', () => {
    expect(validateTour({ title: 'T', category: 'food', tastings: [{ nameZh: '小籠包' }] })).toMatchObject({
      ok: false,
      errors: { tastings: expect.any(String) },
    })
    expect(validateTour({ title: 'T', category: 'food', mainImage: '../../etc/passwd' })).toMatchObject({
      ok: false,
      errors: { mainImage: expect.any(String) },
    })
  })
})
